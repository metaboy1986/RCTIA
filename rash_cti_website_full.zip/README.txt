
Rash CTI - Cyber Threat Intelligence Website

FILES:
- index.html : Main homepage
- styles.css : Styling and layout
- script.js  : Falling stars animation
- assets/    : Folder for images, logos (currently empty)

INSTRUCTIONS:
1. Upload contents to your hosting server (like cPanel or Netlify).
2. Open index.html in a browser to view locally.
3. Customize text, logos, or content as needed.
