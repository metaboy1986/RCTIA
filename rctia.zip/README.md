# RCTIA Automation
Instructions to setup the cron and GitHub.
