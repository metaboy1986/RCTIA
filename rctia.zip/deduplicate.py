# Remove duplicates from data.json
